Adali Montoya — One-page Portfolio

FILES
- index.html
- styles.css
- script.js
- assets/ (put your videos here)

VIDEOS
Add MP4 files (small if possible) into /assets:
- hero.mp4
- work1.mp4
- work2.mp4
- work3.mp4
- work4.mp4

If you don't add videos yet, the site still shows poster images.
